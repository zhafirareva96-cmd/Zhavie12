# mandelbrot set 

A Pen created on CodePen.

Original URL: [https://codepen.io/Zhafira-Reva/pen/oNrKOBx](https://codepen.io/Zhafira-Reva/pen/oNrKOBx).

