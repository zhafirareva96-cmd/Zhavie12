//------> https://en.m.wikipedia.org/wiki/Mandelbrot_set

var canvas = document.querySelector("canvas");
var ctx = canvas.getContext("2d");

function checkIfInOut(x, y) {
    var real = x;
    var imag = y;
    var maxI = 100;
    for(var i = 0; i < maxI; i++) {

         var tempReal = real*real - imag*imag + x;
         var tempImag = 2*real*imag + y;
         real = tempReal;
         imag = tempImag;
      
         if (real * imag > 5)
           return (i/maxI * 100); // Inside the Mandelbrot set
    }
    
    return 0; // Outside the Mandelbrot set
}

function drawSet(magnification, x0, y0, hue) {
  for(var x = 0; x < canvas.width; x++) {
     for(var y = 0; y < canvas.height; y++) {
         var belongsToSet = 
              checkIfInOut(x/canvas.width*5/magnification - x0,                                      
                           y/canvas.height*4/magnification - y0);
         if(belongsToSet == 0) {
              ctx.fillStyle = 'black';
              ctx.fillRect(x,y, 1,1); 
         }                
       else {
          ctx.fillStyle = 'hsl(' + hue + ', 100%, ' + belongsToSet + '%)';
          ctx.fillRect(x,y, 1,1); // Draw a colorful pixel
          }
     } 
  }
}

var magnif = 3;
var hue = Math.random()*360;

drawSet(1, 3.1, 2, hue);

//var x_0 = 2.6, y_0 = 2;

/* //---TODO: magnification on click
canvas.onclick = function(e) {
  var fieldCoords = canvas.getBoundingClientRect();
  var fieldInnerCoords = {
    top: fieldCoords.top + canvas.clientTop,
    left: fieldCoords.left + canvas.clientLeft
    };
  var canvX = Math.floor(e.clientX - fieldInnerCoords.left);
  var canvY = Math.floor(e.clientY - fieldInnerCoords.top);
  //magnif += 10;
  //drawSet(magnif, 2.6, 1.5, hue);
  x_0 = (2 + x_0 - 4*canvX/canvas.width)/magnif;
  y_0 = (2 + y_0 - 3*canvY/canvas.height)/magnif;
  drawSet(magnif, x_0, y_0, hue);
  magnif += 2;  
}*/

var home = document.getElementById("home");
home.onclick = function(e) {
  hue = Math.random()*360;
  drawSet(1, 3.1, 2, hue);
  //magnif = 2;
  //x_0 = 2.6;
  //y_0 = 2;
}


                                   